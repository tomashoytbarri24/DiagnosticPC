"""Persistencia local de CorePulse."""
